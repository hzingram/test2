Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module AuditPolicyDsc -Confirm:$False
Install-Module ComputerManagementDsc -Confirm:$False
Install-module SecurityPolicyDsc -Confirm:$False

.\CIS_WindowsServer2019_v110.ps1

Set-Item -Path WSMan:\localhost\MaxEnvelopeSizeKb -Value 2048
winrm quickconfig

$SecurePass = ConvertTo-SecureString -String "P@ssw0rd" -AsPlainText -Force
New-LocalUser "other_admin" -Password $SecurePass -FullName "Other Admin" -Description "Other Administrator"
Add-LocalGroupMember -Group "Administrators" -Member "other_admin"

Start-DscConfiguration -Path .\CIS_WindowsServer2019_v110  -Force -Verbose -Wait
Test-DscConfiguration -Path .\CIS_WindowsServer2019_v110  -Verbose
